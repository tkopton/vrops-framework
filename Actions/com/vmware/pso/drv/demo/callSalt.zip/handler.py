from sseapiclient import APIClient

def handler(context, inputs):
	outputs = {}
	minion_id = inputs["minionID"]
	msg = "Run Call with Minion ID: {0}!".format(minion_id)

	#connection info
	sec_host = inputs["saltHost"]
	username = inputs["username"]
	password = inputs["password"]
	validate_ssl = inputs["validateSSL"]
	jobid  = inputs["jobId"]
	command = inputs["command"]

	client = APIClient(sec_host, username, password, ssl_validate_cert=validate_ssl)
	response = getattr(client.api.cmd,route_cmd(job_uuid=jobid,tgt={"*": {"tgt": minion_id, "tgt_type": "glob"}},))
	outputs["greetings"]=msg
	outputs["response"]=response
	return outputs


