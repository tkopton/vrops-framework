"""
    :codeauthor: Pedro Algarvio (pedro@algarvio.me)

    salt.config.schemas
    ~~~~~~~~~~~~~~~~~~~

    Salt configuration related schemas for future validation
"""
